1. Add tokens in data/tokens.txt as token / mail:pass:token
2. Add proxies in data/proxies.txt as username:pass@host:port
3. Run main.py [ make sure to install all the modules yourself ]
